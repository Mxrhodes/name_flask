from flask import Flask, render_template, request, redirect

app = Flask(__name__)

USERS = []

@app.route('/')
def index():
  return render_template("index.html")

@app.route('/process', methods=['POST'])
def create_user():

    name = request.form['name']
    count = 1
    name = str(count) + " - Name: " + name
    USERS.append(name)
    for user in USERS:
       count += 1
    print "New Name Added"
    print user
    return redirect('/')


app.run(debug=True)